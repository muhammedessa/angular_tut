import { Component, OnInit } from '@angular/core'; 
import { UserInfo } from 'src/app/model/userInfo';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  name: string = '';
  email: string = '';


  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  send(): void {
  
    console.log(this.name + ' ' + this.email )

    this.userService.addUser( new UserInfo(this.name, this.email))
      .subscribe(
        (response) => {                           //next() callback
          console.log('response received')
          console.log(response);
        },
        (error) => {                              //error() callback
          console.error('Request failed with error')
          console.log(error);
        },
        () => {                                   //complete() callback
          console.error('Request completed')      //This is actually not needed 
          console.log('Request completed');
        })

  }

  

}
