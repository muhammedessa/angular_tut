import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  title = 'apiapp';

  users: User[] = [];

  loading: boolean = false;
  errorMessage: any;

  constructor(private userService: UserService) { }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  public getRepos() {
    this.loading = true;
    this.errorMessage = "";
    this.userService.getRepos()
      .subscribe(
        (response) => {                           //next() callback
          console.log('response received')
          console.log(response)
          this.users = response;
        },
        (error) => {                              //error() callback
          console.error('Request failed with error')
          this.errorMessage = error;
          this.loading = false;
        },
        () => {                                   //complete() callback
          console.error('Request completed')      //This is actually not needed 
          this.loading = false;
        })
  }

}
