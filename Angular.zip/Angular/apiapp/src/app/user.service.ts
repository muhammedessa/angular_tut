import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './model/user';
import { UserInfo } from './model/userInfo';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseURL: string = "http://192.168.0.115:8081/";

  constructor(private http: HttpClient) { }

  getRepos(): Observable<any> { 
    return this.http.get(this.baseURL + 'users' )
  }

  // HttpClient API post() 
  addUser(user: UserInfo): Observable<any> {

    const headers = new HttpHeaders({
      'Content-Type': 'application/json', 
      'Access-Control-Allow-Headers': 'Content-Type', 
    }); 
    const body = JSON.stringify(user);
    console.log(body);
    return this.http.post(this.baseURL + 'user', body, { 'headers': headers, observe: 'response' })
      
}
  
}
