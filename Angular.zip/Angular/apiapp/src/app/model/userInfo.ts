export class UserInfo{ 
    Name: string
    Email: string 

    constructor( Name: string, Email: string){
        this.Name = Name
        this.Email = Email
    }


}