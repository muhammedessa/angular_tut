export class User{
    ID:number
    CreatedAt:string
    UpdatedAt: string
    Name: string
    Email: string 


    constructor( ID: number, CreatedAt: string, UpdatedAt: string, 
                 Name: string, Email: string){

        this.ID = ID
        this.CreatedAt = CreatedAt
        this.UpdatedAt = UpdatedAt
        this.Name = Name
        this.Email = Email
    }


}