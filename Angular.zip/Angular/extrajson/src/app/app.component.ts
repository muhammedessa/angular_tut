import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { Post } from './model/Post';


type PostInfo = { userId: number, id: number, title: string, body: string};

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'extrajson';

  posts: any;

  constructor(http: HttpClient){
    const postss:Observable<Post> = http.get<Post>('/assets/posts.json');
    postss.subscribe(post=>{
      this.posts = post;
      console.log(this.posts)
    })
  }

  
}
