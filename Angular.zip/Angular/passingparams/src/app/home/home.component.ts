import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  image1 = "https://images.pexels.com/photos/47261/pexels-photo-47261.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260";
  image2 = "https://images.pexels.com/photos/66387/stars-night-mountains-lake-66387.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260";
  image3 = "https://images.pexels.com/photos/48605/pexels-photo-48605.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260";
  image4 = "https://images.pexels.com/photos/1851415/pexels-photo-1851415.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260";

}
