import { getSafePropertyAccessString } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Post } from './models/Post';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  posts:Post[]=[];

  constructor() { 
    this.getPosts()
  }

  getPosts() {

    this.posts = [
      new Post(1, 'Lorem', 'Lorem Ipsum is simply dummy text of the printing and typesetting', 'Muhammed Essa', 'Kirkuk'),
      new Post(2, 'Ipsum', 'Lorem Ipsum is simply dummy text of the printing and typesetting', 'Ahmed Essa', 'Baghdad'),
      new Post(3, 'simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting', 'Osama Essa', 'Mosul'),
      new Post(4, 'dummy', 'Lorem Ipsum is simply dummy text of the printing and typesetting', 'Ali Essa', 'Sulaymaniyeh'),
      new Post(5, 'printing', 'Lorem Ipsum is simply dummy text of the printing and typesetting', 'Omer Essa', 'Wasit')
    ]
    return this.posts;
  }

  getPostById(id:number){
    var result = this.posts.filter(obj=>{
      return obj.id === id
    })
    
    return result;
  }

}

