import { Component } from '@angular/core';
import { ProductService} from './product.service';
import { Product } from './Product'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  products: Product[] =[];
  productService;


  constructor() {
    this.productService = new ProductService();
  }

  getProducts(){
    this.products = this.productService.getAllProducts();
  }


mydate = new Date();
myJson = {name:'Muhammed',age:'37',department:'Front End Developer' 
          , address:{city:'kirkuk',phoneNumer:12321321}}
myArrayNum = [22,33,44,55,66,77,88]




printNumber:number = 12;
  printNumber2: number = 12;
fullName :string = "Osama Essa"

  result = this.printNumber * this.printNumber2;

sum(){
  return this.printNumber + this.printNumber2;
}

  onClick1() {
    console.log("You have just, clicked !!");
  }


  someText:string = "You can change me";


  title = 'myblog';
 myname = "Muhammed Essa"
 myInfo:boolean = true;
  myAge : number = 37;
 myName: string = "Alice";



 greet(name: string, name2:string) {
   console.log("Hello, " + name + name2 + "!!");
   
   
}

  dataInfo: boolean = true;
  
  names = [1,2,3,4,5,6,7,8];

   
    

  customersArray: Customer[] = [
    {
      name: 'Muhammed',
      age: 37,
      city: 'Kirkuk'
    },
    {
      name: 'Ahmed',
      age: 21,
      city: 'Babil'
    },
    {
      name: 'Ali',
      age: 44,
      city: 'Baghdad'
    }
  ];

  personObject = {
    name: 'Muhammed',
    age: '37',
    city: 'Kirkuk'
  }

}

class Customer{
  name:string="";
  age:number=0;
  city:string="";
}
