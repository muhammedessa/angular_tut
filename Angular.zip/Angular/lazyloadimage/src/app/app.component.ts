import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lazyloadimage';
 
  imageSrc1 = "https://images.pexels.com/photos/264636/pexels-photo-264636.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
  imageSrc2 = "https://images.pexels.com/photos/709817/pexels-photo-709817.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500"
  imageSrc3 = "https://images.pexels.com/photos/1070979/pexels-photo-1070979.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500"
  imageSrc4 = "https://images.pexels.com/photos/1508666/pexels-photo-1508666.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500"

}
