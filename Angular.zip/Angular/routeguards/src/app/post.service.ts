import { Injectable } from '@angular/core';
import {Post} from './model/post'

@Injectable({
  providedIn: 'root'
})
export class PostService {
   posts: Post[] = [];
   constructor(){
     this.getPosts()
   }
  getPosts(){
    
    this.posts = [
      new Post(1,'Lorem', 'Lorem Ipsum is simply dummy text of the printing and typesetting ', 'Muhammed Essa', 'Kirkuk') ,
      new Post(2,'Ipsum', 'Lorem Ipsum is simply dummy text of the printing and typesetting ', 'Ahmed Essa', 'Baghdad'),
      new Post(3,'Simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting ', 'Osama Essa', 'Sulaymaniyeh'),
      new Post(4,'Dummy', 'Lorem Ipsum is simply dummy text of the printing and typesetting ', 'Ali Essa', 'Diyala')
    ]
    return this.posts;
  }

  getPostById(id:number) {
    
    var result = this.posts.filter(obj => {
      return obj.id === id
    })
    console.log(result) 
    return result;
  }
  
}
