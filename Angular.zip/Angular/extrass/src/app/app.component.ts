import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'extrass';


  name:string = '';
  email:string='';

  send():void{
    console.log(this.name + " " + this.email) 
    console.log(Number(this.name) + Number(this.email))
  }

}
